package com.example.hw5q4

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private var gyroscope: Sensor? = null
    private lateinit var gameView: GameView
    private val sensitivity = 5f  // adjust as needed

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        gameView = GameView(this)
        setContentView(gameView)

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
    }

    override fun onResume() {
        super.onResume()
        gyroscope?.also { sensor ->
            sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent?) {
        event?.let {
            // Use gyroscope values to update ball movement.
            // Negative sign adjusts the direction mapping as needed.
            val deltaX = -it.values[1] * sensitivity
            val deltaY = it.values[0] * sensitivity
            gameView.updateBall(deltaX, deltaY)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    // Custom View that draws the ball and obstacles.
    inner class GameView(context: Context) : View(context) {
        private var ballX = 100f
        private var ballY = 100f
        private val ballRadius = 30f
        private val ballPaint = Paint().apply { color = Color.BLUE }
        private val wallPaint = Paint().apply { color = Color.RED }
        // Define some static obstacles
        private val walls = listOf(
            RectF(200f, 200f, 400f, 220f),
            RectF(200f, 400f, 220f, 600f),
            RectF(300f, 500f, 500f, 520f)
        )

        fun updateBall(deltaX: Float, deltaY: Float) {
            // Update ball position.
            ballX += deltaX
            ballY += deltaY

            // Check boundaries.
            if (ballX - ballRadius < 0) ballX = ballRadius
            if (ballY - ballRadius < 0) ballY = ballRadius
            if (ballX + ballRadius > width) ballX = width - ballRadius
            if (ballY + ballRadius > height) ballY = height - ballRadius

            // Simple collision detection with walls.
            val ballRect = RectF(ballX - ballRadius, ballY - ballRadius, ballX + ballRadius, ballY + ballRadius)
            for (wall in walls) {
                if (RectF.intersects(ballRect, wall)) {
                    // Revert the move on collision.
                    ballX -= deltaX
                    ballY -= deltaY
                    break
                }
            }
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            // Draw ball.
            canvas.drawCircle(ballX, ballY, ballRadius, ballPaint)
            // Draw obstacles.
            walls.forEach { canvas.drawRect(it, wallPaint) }
        }
    }
}
