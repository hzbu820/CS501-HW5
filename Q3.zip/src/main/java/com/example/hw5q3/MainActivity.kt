package com.example.hw5q3

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.concurrent.thread
import kotlin.math.log10

class MainActivity : AppCompatActivity() {

    private lateinit var audioRecord: AudioRecord
    private lateinit var progressBar: ProgressBar
    private var isRecording = false
    private val noiseThreshold = 70.0 // in dB

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        progressBar = findViewById(R.id.progressBar)

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
        } else {
            startSoundMeter()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.isNotEmpty()
            && grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            startSoundMeter()
        } else {
            Toast.makeText(this, "Permission denied.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startSoundMeter() {
        // Check permission again before recording
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Audio permission not granted", Toast.LENGTH_SHORT).show()
            return
        }

        val sampleRate = 44100
        val bufferSize = AudioRecord.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        if (bufferSize <= 0) {
            Toast.makeText(this, "Unsupported sample rate or config.", Toast.LENGTH_SHORT).show()
            return
        }

        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            bufferSize
        )

        try {
            audioRecord.startRecording()
        } catch (e: SecurityException) {
            Toast.makeText(this, "Recording permission not granted", Toast.LENGTH_SHORT).show()
            return
        }

        isRecording = true
        val buffer = ShortArray(bufferSize)

        thread {
            while (isRecording) {
                val read = audioRecord.read(buffer, 0, buffer.size)
                if (read > 0) {
                    val maxAmplitude = buffer.take(read).maxOrNull()?.toDouble() ?: 0.0
                    val dB = if (maxAmplitude > 0) 20 * log10(maxAmplitude) else 0.0
                    runOnUiThread {
                        progressBar.progress = dB.toInt().coerceIn(0, 120)
                        if (dB > noiseThreshold) {
                            Toast.makeText(this, "Noise level exceeded!", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        isRecording = false
        if (::audioRecord.isInitialized) {
            audioRecord.stop()
            audioRecord.release()
        }
        super.onDestroy()
    }
}
